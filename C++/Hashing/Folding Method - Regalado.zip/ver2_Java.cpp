#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void FoldingMethod(const char *array[]) {

	int arraysize = 106, //total number of java keywords doubled (original arraysize is 53 since there are 53 java keywords)
			n,
			count = 0,
			sum = 0,
			i,
			j,
			collisions = 0,
			hashVal[53], //int array where the keywords' hashVals are stored for reference
			divisor; //divisor to be used in the Prime Division method

	//this while loop iterates through all the 50 java keywords
	while(count != 53){
		//gets the current keyword's string length
		n = strlen(array[count]);

		/*This entire for loop converts the keyword(character string) into
			an integer sum. Since all keywords only have lowercase letters,
			I've assigned their num to increment in accordance with their
			index in the alphabet added by 1 so that it starts at 1(a) and ends
			at 26(z). Additionally, I've also added a multiplier. Depending on
			the character's index within the keyword, its current sum is multiplied
			by n which ranges from 1 to 13 since 12 is the max string length among
			all the java keywords (synchronized has 12 as its string length).
		*/

		for(i = 0; i < n; i++){
				if(array[count][i] == 'a'){
					sum += 1;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'b'){
					sum += 2;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'c'){
					sum += 3;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'd'){
					sum += 4;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'e'){
					sum += 5;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'f'){
					sum += 6;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'g'){
					sum += 7;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'h'){
					sum += 8;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'i'){
					sum += 9;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'j'){
					sum += 10;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'k'){
					sum += 11;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'l'){
					sum += 12;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'm'){
					sum += 13;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'n'){
					sum += 14;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'o'){
					sum += 15;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'p'){
					sum += 16;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'q'){
					sum += 17;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'r'){
					sum += 18;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 's'){
					sum += 19;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 't'){
					sum += 20;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'u'){
					sum += 21;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'v'){
					sum += 22;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'w'){
					sum += 23;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'x'){
					sum += 24;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'y'){
					sum += 25;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
				else if(array[count][i] == 'z'){
					sum += 26;

					if(i == 0)
						sum *= 1;
					else if(i == 1)
						sum *= 2;
					else if(i == 2)
						sum *= 3;
					else if(i == 3)
						sum *= 4;
					else if(i == 4)
						sum *= 5;
					else if(i == 5)
						sum *= 6;
					else if(i == 6)
						sum *= 7;
					else if(i == 7)
						sum *= 8;
					else if(i == 8)
						sum *= 9;
					else if(i == 9)
						sum *= 10;
					else if(i == 10)
						sum *= 11;
					else if(i == 11)
						sum *= 12;


				}
			//after it finishes converting the entire keyword, the sum is generated.
			if(i == n-1){
				divisor = 103; //greatest prime number before 106(doubled arraysize)
				hashVal[count] = sum % divisor; //generates hashVal through Prime Division method

				//prints the generated hashVal of the current keyword
				printf("[%d] Hash value of %s is = %d\n", count, array[count], hashVal[count]);
			}
		}
		/*for loop that checks if the latest generated hashVal has an equivalent hashVal with
			any of the 31 other keywords.
		*/
		for(j = 0; j < 53; j++){ //iterates through the 53 keys that may or may not have any hashVals yet
			//if current hashVal is equal to any hashVal and their index is not the same, then a collision has occurred
			if(hashVal[count] == hashVal[j] && count != j){
				collisions++;
			}
		}
		//sum is reset to 0 since the while loop will start from the top/start with the next keyword
		sum = 0;
		/*count is incremented in order to iterate through every keyword in the array
			(This while loop will loop a total of 53 times since there are 53 java keywords)
		*/
		count++;
	}
	//prints the number of collisions detected
	printf("\ncollisions = %d\n", collisions);
}

int main()
{
	const char *array[50]; //java keywords are instantiated in a character array
		array[0] = "abstract";
		array[1] = "assert";
		array[2] = "boolean";
		array[3] = "break";
		array[4] = "byte";
		array[5] = "case";
		array[6] = "catch";
		array[7] = "char";
		array[8] = "class";
		array[9] = "const";
		array[10] = "continue";
		array[11] = "default";
		array[12] = "do";
		array[13] = "double";
		array[14] = "else";
		array[15] = "enum";
		array[16] = "extends";
		array[17] = "final";
		array[18] = "finally";
		array[19] = "float";
		array[20] = "for";
		array[21] = "goto";
		array[22] = "if";
		array[23] = "implements";
		array[24] = "import";
		array[25] = "instanceof";
		array[26] = "int";
		array[27] = "interface";
		array[28] = "long";
		array[29] = "native";
		array[30] = "new";
		array[31] = "package";
		array[32] = "private";
		array[33] = "protected";
		array[34] = "public";
		array[35] = "return";
		array[36] = "short";
		array[37] = "static";
		array[38] = "strictfp";
		array[39] = "super";
		array[40] = "switch";
		array[41] = "synchronized";
		array[42] = "this";
		array[43] = "throw";
		array[44] = "throws";
		array[45] = "transient";
		array[46] = "try";
		array[47] = "void";
		array[48] = "volatile";
		array[49] = "while";
		array[50] = "false";
		array[51] = "true";
		array[52] = "null";

		int choice;
		char option = 'y';

		do{
		printf("\n ~ HASH FUNCTIONS FOR JAVA: ~ \n\n");
		printf("[1] - Prime Division Method\n");
		printf("[2] - Digit Exraction Method\n");
		printf("[3] - Folding Method\n\n");

		printf("Please pick a Hash Function you want to use: ");
		scanf("%d", &choice);

		if(choice == 1){
			//insert function call for Prime Division Method here
			printf("\nWould you like to use another method? (Y/N): ");
			scanf(" %c", &option);
		}
		else if(choice == 2){
			//insert function call for Digit Exraction Method here
			printf("\nWould you like to use another method? (Y/N): ");
			scanf(" %c", &option);
		}
		else if(choice == 3){
			printf("\nYou have selected [3] - Folding Method\n\n");
			FoldingMethod(array); //function call for Folding method
			printf("\nWould you like to use another method? (Y/N): ");
			scanf(" %c", &option);
		}
		else{
			do{
				printf("\nInvalid input. Please select only among the 3 choices provided: ");
				scanf("%d", &choice);

				if(choice == 1){
					//insert function call for Prime Division Method here
					printf("\nWould you like to use another method? (Y/N): ");
					scanf(" %c", &option);
				}
				else if(choice == 2){
					//insert function call for Digit Exraction Method here
					printf("\nWould you like to use another method? (Y/N): ");
					scanf(" %c", &option);
				}
				else if(choice == 3){
					printf("\nYou have selected [3] - Folding Method\n\n");
					FoldingMethod(array); //function call for Folding method
					printf("\nWould you like to use another method? (Y/N): ");
					scanf(" %c", &option);
				}
			}while(choice < 1 || choice > 3);
		}
	}while(option == 'Y' || option == 'y');

    return 0;
}
